import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { initializeGeometry, DEFAULTS, LIMITS, buildShelf, fitBed, stl, threeMF } from './geometry.js';

const $=id=>document.getElementById(id);
let state={...DEFAULTS}, mesh=null, ready=false, timer, toastTimer, lastSize=0;
const inputs=new Map();
const fmt=n=>Number(n.toFixed(1)).toString();
const STYLE_INFO={flat:['Your custom shelf','Open front and sides.'],tray:['Your custom tray','Raised edges keep small things contained.'],rounded:['Your rounded tray','Raised edges with soft corners.'],semicircle:['Your half-round shelf','A curved front with a straight back against the board.'],openbin:['Your open-front bin','Tall sides and a fully open front for easy access.'],cup:['Your custom cup','Set equal width and depth for a round cup, or different values for an oval.'],phone:['Your phone stand','An angled back, retaining lip, and 14 mm cable opening.'],holder:['Your bottle / tool holder','Through-openings for tools or objects with a wider shoulder. Size each opening to your object.'],tilted:['Your tilted shelf','The front rises away from the board, with a lip to retain display items.']};
function field(key,label,container,range=true,unit='mm') {
  const [min,max]=LIMITS[key],step=['wall','floor','clearance','board','slot'].includes(key)?0.1:1;
  const div=document.createElement('div');div.className='field';
  div.innerHTML=`<div class="field-label"><label for="${key}">${label}</label><div class="number-wrap"><input id="${key}" type="number" min="${min}" max="${max}" step="${step}" value="${state[key]}" inputmode="decimal"><span>${unit}</span></div></div>${range?`<input type="range" aria-label="${label}" id="${key}Range" min="${min}" max="${max}" step="${step}" value="${state[key]}">`:''}`;
  $(container).append(div);inputs.set(key,div);
  const number=div.querySelector('input[type=number]'), slider=div.querySelector('input[type=range]');
  number.addEventListener('input',()=>{
    state[key]=number.value===''?NaN:Number(number.value);if(slider&&Number.isFinite(state[key]))slider.value=state[key];queueBuild();
  });
  if(slider)slider.addEventListener('input',()=>{state[key]=Number(slider.value);number.value=state[key];queueBuild();});
}
field('width','Width','sizeControls');field('depth','Depth','sizeControls');field('height','Edge height','sizeControls');
field('radius','Corner radius','radiusControl');field('wall','Wall thickness','wallControl',false);field('floor','Base thickness','floorControl',false);
field('holeDiameter','Opening diameter','styleControls');field('holeCount','Number of openings','styleControls',true,'');field('phoneHeight','Phone back height','styleControls');field('phoneGap','Phone pocket gap','styleControls');field('angle','Tilt angle','styleControls',true,'°');
field('supportReach','Reach under shelf','supportControls');field('supportHeight','Height below shelf','supportControls');field('supportThickness','Bracket thickness','supportControls',false);
field('pitch','Slot spacing','mountControls',false);field('board','Board thickness','mountControls',false);field('slot','Slot width','mountControls',false);field('clearance','Fit clearance','mountControls',false);field('hookDrop','Hook tail length','mountControls',false);
field('rowPitch','Vertical row spacing','mountControls',false);
field('bedX','Width (X)','bedControls',false);field('bedY','Depth (Y)','bedControls',false);field('bedZ','Height (Z)','bedControls',false);

function syncUI(){
  document.querySelectorAll('[data-style]').forEach(b=>{const active=b.dataset.style===state.style;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
  for(const [key,div] of inputs){div.querySelectorAll('input').forEach(i=>i.value=state[key]);}
  $('radiusControl').hidden=state.style!=='rounded';
  inputs.get('height').hidden=!['tray','rounded','openbin','cup'].includes(state.style);
  inputs.get('height').querySelector('label').textContent=state.style==='cup'?'Cup height':state.style==='openbin'?'Side height':'Edge height';
  for(const key of ['holeDiameter','holeCount'])inputs.get(key).hidden=state.style!=='holder';
  for(const key of ['phoneHeight','phoneGap'])inputs.get(key).hidden=state.style!=='phone';
  inputs.get('angle').hidden=!['phone','tilted'].includes(state.style);
  inputs.get('rowPitch').hidden=state.hookType!=='double';
  $('compartments').closest('label').hidden=!['tray','rounded','openbin'].includes(state.style);$('compartments').value=state.compartments;
  $('braces').checked=state.braces;
  $('braces').closest('label').hidden=!['flat','tray','rounded','openbin'].includes(state.style);
  $('previewTitle').textContent=STYLE_INFO[state.style][0];$('styleDescription').textContent=STYLE_INFO[state.style][1];
  $('hookType').value=state.hookType;
  $('hookCount').innerHTML='<option value="0">Automatic</option>'+Array.from({length:8},(_,i)=>i+1).filter(n=>state.hookType!=='double'||n%2===0).map(n=>`<option value="${n}">${n} ${n===1?'hook':'hooks'}</option>`).join('');$('hookCount').value=state.hookCount;
  $('hookDescription').textContent={standard:'Insert the hooks, then slide down to seat them.',tapered:'Narrower tips help guide the hooks into the slots; the neck stays full width.',double:'Hooks engage two rows in the same columns. Check the vertical spacing on your board.'}[state.hookType];
  $('bottomSupports').checked=state.bottomSupports;$('supportOptions').hidden=!state.bottomSupports;$('supportCount').value=state.supportCount;
  $('insertionHeight').textContent=`${fmt(state.hookDrop+3.2)} mm`;
}
document.querySelectorAll('[data-style]').forEach(b=>b.addEventListener('click',()=>{state.style=b.dataset.style;if(state.style==='cup')state.height=65;if(state.style==='openbin')state.height=40;if(state.style==='holder'){state.holeDiameter=Math.min(state.holeDiameter,state.depth-2*state.wall,state.width-2*state.wall);state.holeCount=Math.max(1,Math.min(state.holeCount,Math.floor((state.width-state.wall)/(state.holeDiameter+state.wall))));}lastSize=0;syncUI();queueBuild();}));
$('compartments').addEventListener('change',e=>{state.compartments=Number(e.target.value);queueBuild();});
$('braces').addEventListener('change',e=>{state.braces=e.target.checked;queueBuild();});
$('hookType').addEventListener('change',e=>{state.hookType=e.target.value;if(state.hookType==='double'&&state.hookCount%2)state.hookCount=Math.min(8,state.hookCount+1);lastSize=0;syncUI();queueBuild();});
$('hookCount').addEventListener('change',e=>{state.hookCount=Number(e.target.value);queueBuild();});
$('bottomSupports').addEventListener('change',e=>{state.bottomSupports=e.target.checked;lastSize=0;syncUI();queueBuild();});
$('supportCount').addEventListener('change',e=>{state.supportCount=Number(e.target.value);queueBuild();});
$('reset').addEventListener('click',()=>{state={...DEFAULTS};syncUI();queueBuild();});
$('helpBtn').addEventListener('click',()=>$('helpDialog').showModal());
for(const id of ['closeHelp','gotIt'])$(id).addEventListener('click',()=>$('helpDialog').close());
$('helpDialog').addEventListener('click',e=>{if(e.target===$('helpDialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});
$('jumpPreview').addEventListener('click',()=>document.querySelector('.preview-panel').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'}));
new IntersectionObserver(([entry])=>{$('jumpPreview').hidden=entry.isIntersecting;}).observe(document.querySelector('.preview-panel'));

let renderer,scene,camera,orbit,modelGroup,grid,ground,renderMesh,edges;
let view='iso';
function initViewer(){
  const container=$('viewer');
  try{
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
    renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor(0,0);
    renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    renderer.outputColorSpace=THREE.SRGBColorSpace;container.append(renderer.domElement);
    scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(34,1,0.1,5000);camera.up.set(0,0,1);
    orbit=new OrbitControls(camera,renderer.domElement);orbit.enableDamping=true;orbit.dampingFactor=.09;orbit.enablePan=false;orbit.minDistance=45;orbit.maxDistance=1800;
    scene.add(new THREE.AmbientLight(0xffffff,1.7));
    const light=new THREE.DirectionalLight(0xffffff,3.5);light.position.set(-120,80,250);light.castShadow=true;light.shadow.mapSize.set(2048,2048);light.shadow.camera.left=-300;light.shadow.camera.right=300;light.shadow.camera.top=300;light.shadow.camera.bottom=-300;light.shadow.normalBias=.25;light.shadow.bias=-.0003;scene.add(light);
    const fill=new THREE.DirectionalLight(0x8ab5ff,1.5);fill.position.set(130,-150,90);scene.add(fill);
    grid=new THREE.GridHelper(500,25,0xc9d5e7,0xdfe6f2);grid.rotation.x=Math.PI/2;grid.position.z=-.5;grid.material.transparent=true;grid.material.opacity=.55;scene.add(grid);
    ground=new THREE.Mesh(new THREE.PlaneGeometry(1600,1600),new THREE.ShadowMaterial({opacity:.09}));ground.position.z=-.4;ground.receiveShadow=true;scene.add(ground);
    modelGroup=new THREE.Group();scene.add(modelGroup);
    const resize=()=>{const w=container.clientWidth,h=container.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();};
    new ResizeObserver(resize).observe(container);resize();
    renderer.setAnimationLoop(()=>{orbit.update();renderer.render(scene,camera);});
  }catch(e){$('viewerError').hidden=false;$('viewerError').textContent='3D preview is unavailable in this browser. Try Chrome or Edge with graphics acceleration enabled. You can still customize and download the model.';}
}
function setCamera(){
  if(!mesh||!camera)return;
  const size=Math.max(mesh.dims[0],mesh.dims[1],mesh.dims[2]*1.25), z=mesh.dims[2]/2;
  const narrow=camera.aspect<1?1/camera.aspect:1;const distance=size*1.9*narrow;
  orbit.target.set(0,0,z);
  ground.visible=view!=='under';grid.visible=view!=='under';
  if(view==='top'){camera.position.set(0,0,distance*1.35);camera.up.set(0,1,0);}
  else if(view==='back'){camera.position.set(size*.05,-distance,z+size*.13);camera.up.set(0,0,1);}
  else if(view==='under'){camera.position.set(distance*.6,distance*.6,-distance*.45);camera.up.set(0,0,1);}
  else {camera.position.set(distance*.58,distance*.65,distance*.58);camera.up.set(0,0,1);}
  orbit.update();
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.view;document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el===b));setCamera();}));

function showMesh(m){
  if(!renderer||!modelGroup)return;
  modelGroup.visible=true;
  for(const obj of [renderMesh,edges])if(obj){modelGroup.remove(obj);obj.geometry.dispose();obj.material.dispose();}
  const verts=new Float32Array(m.triangles.length*9);let at=0;
  for(const ids of m.triangles)for(const id of ids)for(const n of m.vertices[id])verts[at++]=n;
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(verts,3));geometry.computeVertexNormals();
  const mat=new THREE.MeshStandardMaterial({color:0x3b62ef,roughness:.48,metalness:.06});
  renderMesh=new THREE.Mesh(geometry,mat);renderMesh.castShadow=true;renderMesh.receiveShadow=true;modelGroup.add(renderMesh);
  edges=new THREE.LineSegments(new THREE.EdgesGeometry(geometry,25),new THREE.LineBasicMaterial({color:0x193991,transparent:true,opacity:.28}));modelGroup.add(edges);
  modelGroup.position.set(-(m.bounds[0][0]+m.bounds[1][0])/2,-(m.bounds[0][1]+m.bounds[1][1])/2,-m.bounds[0][2]);
  const delta=m.dims[2]/2-orbit.target.z;orbit.target.z+=delta;camera.position.z+=delta;
  const size=Math.max(...m.dims);if(!lastSize||size/lastSize>1.4||size/lastSize<.65){setCamera();lastSize=size;}
}
function buttons(disabled){$('download3mf').disabled=disabled;$('downloadStl').disabled=disabled;$('testDownload').disabled=!ready;}
function queueBuild(){clearTimeout(timer);buttons(true);$('meshStatus').textContent='Updating…';timer=setTimeout(rebuild,110);}
function rebuild(){
  if(!ready)return;
  $('bedVolume').textContent=[state.bedX,state.bedY,state.bedZ].every(n=>Number.isFinite(n)&&n>0)?`${[state.bedX,state.bedY,state.bedZ].map(fmt).join(' × ')} mm`:'Enter a valid build volume';
  try{
    const m=buildShelf(state);mesh=m;showMesh(m);const fit=fitBed(m,state);
    const flat=['flat','semicircle','holder','tilted'].includes(state.style), n=['tray','rounded','openbin'].includes(state.style)?state.compartments:1;
    const clearW=flat?state.width:state.width-2*state.wall;
    const clearD=state.depth-state.wall-(flat||state.style==='openbin'?0:state.wall);
    const cell=(clearW-(n-1)*state.wall)/n;
    $('insideSize').textContent=`${fmt(clearW)} × ${fmt(clearD)} mm`;
    $('insideNote').textContent=(flat?'Open front and sides.':`${n>1?`${n} spaces, ${fmt(cell)} mm wide each. `:''}${fmt(state.height)} mm edge height.`)+(state.braces?' Braces occupy the back corners.':'')+(state.style==='rounded'?' Rounded corners reduce corner space.':'');
    if(state.style==='semicircle'){$('insideSize').textContent=`${fmt(state.width)} × ${fmt(state.depth-state.wall)} mm`;$('insideNote').textContent='Maximum span and central depth. Curved edges reduce space at the sides.';}
    if(state.style==='openbin')$('insideNote').textContent=`${n>1?`${n} spaces, ${fmt(cell)} mm wide each. `:''}${fmt(state.height)} mm sides; open front.`+(state.braces?' Braces occupy the back corners.':'');
    if(state.style==='cup')$('insideNote').textContent=`Oval interior, ${fmt(state.height)} mm deep. Equal width and depth makes a round cup.`;
    if(state.style==='phone'){$('insideSize').textContent=`${fmt(state.width-2*state.wall)} × ${fmt(state.phoneGap)} mm`;$('insideNote').textContent=`Phone pocket; ${state.angle}° lean from vertical, ${state.phoneHeight} mm back height.`;}
    if(state.style==='holder'){$('insideSize').textContent=`${state.holeCount} × Ø ${fmt(state.holeDiameter)} mm`;$('insideNote').textContent='Through-openings. Objects need a wider shoulder or collar to stay in place.';}
    if(state.style==='tilted')$('insideNote').textContent=`${state.angle}° incline from horizontal with a front retaining lip.`;
    $('overallSize').textContent=`${m.dims.map(fmt).join(' × ')} mm`;
    $('mountSummary').textContent=`${m.hooks} hooks${m.rows===2?' · 2 rows':` · ${fmt(state.pitch)} mm grid`}`;
    $('hookCountNote').textContent=`${m.hooks} hooks in ${m.positions.length} ${m.positions.length===1?'column':'columns'}${m.rows===2?` × 2 rows, ${fmt(state.rowPitch)} mm apart`:''}.`+(m.hooks===1?' A single hook can allow the shelf to twist.':'');
    $('bedStatus').textContent=fit.fits?(fit.rotate?'Fits · rotate 90°':'Fits'):'Too large';
    $('bedStatus').className=fit.fits?'good':'bad';
    $('meshStatus').textContent='Closed printable mesh';
    $('modelNotice').className='notice'+(!fit.fits?' error':!fit.brimFits?' warning':'');
    $('modelNotice').textContent=!fit.fits?`This model exceeds the ${state.bedX} × ${state.bedY} × ${state.bedZ} mm build volume upright. Reduce its dimensions or check the printer settings to download.`:!fit.brimFits?'The model fits, but leaves little space for a brim. Check its placement in your slicer.':m.bounds[0][2]<-.01?'Parts extend below the shelf floor. Choose the print orientation in your slicer and inspect removable supports under the floor and hooks. Start with the hook test.':'Start with the hook test. Inspect slicer supports for the rear hooks, then check the fit on your board.';
    $('supportSummary').hidden=!state.bottomSupports;$('supportSummary').textContent=`${m.supports} fused ${m.supports===1?'bracket':'brackets'} · ${fmt(state.supportHeight)} mm drop · ${fmt(Math.min(...m.supportReaches))}–${fmt(Math.max(...m.supportReaches))} mm reach. Reach is limited to the shelf shape at each bracket.`;
    buttons(!fit.fits);$('previewTitle').dataset.triangles=m.triangles.length;
  }catch(e){mesh=null;if(modelGroup)modelGroup.visible=false;buttons(true);$('supportSummary').hidden=true;$('hookCountNote').textContent='Adjust the settings to check hook placement.';$('meshStatus').textContent='Adjust the design';$('modelNotice').className='notice error';$('modelNotice').textContent=e.message;$('bedStatus').textContent='Check settings';$('bedStatus').className='bad';$('overallSize').textContent='—';$('mountSummary').textContent='—';$('insideSize').textContent='—';$('insideNote').textContent='Enter valid dimensions to update the preview.';}
  $('insertionHeight').textContent=Number.isFinite(state.hookDrop)?`${fmt(state.hookDrop+3.2)} mm`:'—';
}
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,5000);}
function save(bytes,name,mime){const url=URL.createObjectURL(new Blob([bytes],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);toast(`${name} downloaded. Open it in your slicer.`);}
function download(format){
  try {clearTimeout(timer);rebuild();if(!mesh||!fitBed(mesh,state).fits)return;
    const name=`skadis-${state.style}-${fmt(state.width)}x${fmt(state.depth)}mm-${state.hookType}-${mesh.hooks}hooks${state.bottomSupports?'-braced':''}`;
    save(format==='stl'?stl(mesh):threeMF(mesh,state),`${name}.${format}`,format==='stl'?'model/stl':'model/3mf');
  }catch(e){toast(`Could not download: ${e.message}`);}
}
$('download3mf').addEventListener('click',()=>download('3mf'));$('downloadStl').addEventListener('click',()=>download('stl'));
$('testDownload').addEventListener('click',()=>{try{const test=buildShelf(state,true);if(!fitBed(test,state).fits)throw new Error('The hook test exceeds your printer size.');save(stl(test),`skadis-hook-test-${state.hookType}-${fmt(state.pitch)}mm-spacing.stl`,'model/stl');}catch(e){toast(e.message);}});
buttons(true);syncUI();initViewer();
initializeGeometry().then(()=>{ready=true;rebuild();}).catch(e=>{$('meshStatus').textContent='Unable to load';$('modelNotice').className='notice error';$('modelNotice').textContent='The model engine could not start. Open this file in a current version of Chrome or Edge with WebAssembly enabled.';console.error(e);});
