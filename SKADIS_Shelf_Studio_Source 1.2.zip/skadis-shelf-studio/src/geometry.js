import ManifoldModule from 'manifold-3d';
import wasmData from './wasm-data.js';
import { zipSync, strToU8 } from 'fflate';
let M, CS, pool=[];
const track=o=>{pool.push(o);return o;};
export async function initializeGeometry(){
  if(M) return;
  const wasmBinary=Uint8Array.from(atob(wasmData),c=>c.charCodeAt(0));
  const lib=await ManifoldModule({wasmBinary}); lib.setup(); M=lib.Manifold;CS=lib.CrossSection;
}
const cuboid=({size,center})=>track(track(M.cube(size,true)).translate(center));
const rectangle=({size,center})=>track(track(CS.square(size,true)).translate(center));
const polygon=({points})=>track(new CS([points]));
const roundedRectangle=({size,roundRadius:r,center})=>{
  const pts=[];const [w,d]=size;
  for(const [cx,cy,start] of [[w/2-r,d/2-r,0],[-w/2+r,d/2-r,90],[-w/2+r,-d/2+r,180],[w/2-r,-d/2+r,270]]){
    for(let i=0;i<=12;i++){const a=(start+i*7.5)*Math.PI/180;pts.push([cx+r*Math.cos(a)+center[0],cy+r*Math.sin(a)+center[1]]);}
  }
  return track(new CS([pts]));
};
const extrudeLinear=({height},s)=>track(s.extrude(height));
const translate=(v,g)=>track(g.translate(v));
const rotateX=(r,g)=>track(g.rotate([r*180/Math.PI,0,0]));
const rotateZ=(r,g)=>track(g.rotate([0,0,r*180/Math.PI]));
const union=parts=>track(M.union(parts));
const subtract=(a,b)=>track(a.subtract(b));

export const STYLES = ['flat','tray','rounded','semicircle','openbin','cup','phone','holder','tilted'];
export const DEFAULTS = Object.freeze({ style:'tray', width:160, depth:85, height:16,
  wall:2.4, floor:3.2, radius:8, compartments:1, braces:true,
  hookType:'standard',hookCount:0,rowPitch:40,
  bottomSupports:false,supportCount:2,supportReach:70,supportHeight:40,supportThickness:5,
  holeDiameter:30,holeCount:3,phoneHeight:75,phoneGap:12,angle:15,
  pitch:40, board:5, slot:5, clearance:0.4, hookDrop:8, bedX:260, bedY:260, bedZ:255 });
export const LIMITS = { width:[55,350], depth:[30,250], height:[5,120], wall:[1.6,5],
  floor:[2,8], radius:[0,30], compartments:[1,5], pitch:[20,60], board:[2,10],
  slot:[4,8], clearance:[0.2,1], hookDrop:[5,10], rowPitch:[20,60],hookCount:[0,8],
  supportCount:[1,4],supportReach:[15,250],supportHeight:[15,120],supportThickness:[3,10],
  holeDiameter:[8,100],holeCount:[1,5],phoneHeight:[30,140],phoneGap:[7,25],angle:[5,35],
  bedX:[20,2000], bedY:[20,2000], bedZ:[20,2000] };
export const PART_LABELS={width:'Width',depth:'Depth',height:'Edge height',wall:'Wall thickness',floor:'Base thickness',radius:'Corner radius',compartments:'Compartments',pitch:'Slot spacing',board:'Board thickness',slot:'Slot width',clearance:'Fit clearance',hookDrop:'Hook tail length',rowPitch:'Vertical row spacing',hookCount:'Hook count',supportCount:'Support count',supportReach:'Support reach',supportHeight:'Support height',supportThickness:'Support thickness',holeDiameter:'Opening diameter',holeCount:'Opening count',phoneHeight:'Phone back height',phoneGap:'Phone pocket gap',angle:'Tilt angle',bedX:'Printer width',bedY:'Printer depth',bedZ:'Printer height'};

export function validate(p,mountOnly=false) {
  for (const [key,[lo,hi]] of Object.entries(LIMITS)) {
    if (!Number.isFinite(p[key]) || p[key]<lo || p[key]>hi) throw new Error(`${PART_LABELS[key]}: enter a value between ${lo} and ${hi}.`);
  }
  if (!STYLES.includes(p.style)) throw new Error('Choose a shelf style.');
  for(const k of ['compartments','hookCount','supportCount','holeCount'])if(!Number.isInteger(p[k]))throw new Error(`${PART_LABELS[k]} must be a whole number.`);
  if(!['standard','tapered','double'].includes(p.hookType))throw new Error('Choose a mounting hook type.');
  if(p.hookType==='double' && p.hookCount%2!==0)throw new Error('Two-row hooks need an even total hook count.');
  if (!mountOnly && ['tray','rounded','openbin'].includes(p.style) && (p.width-2*p.wall-(p.compartments-1)*p.wall)/p.compartments <12) throw new Error('Compartments need at least 12 mm of clear width.');
  if (p.slot-p.clearance<3) throw new Error('The hook width must be at least 3 mm.');
  if(!mountOnly&&p.style==='holder'&&(p.holeCount*p.holeDiameter+(p.holeCount+1)*p.wall>p.width||p.holeDiameter+2*p.wall>p.depth))throw new Error('The circular openings do not fit. Reduce their count or diameter, or enlarge the shelf.');
  if(!mountOnly&&p.style==='phone'&&p.phoneHeight*Math.tan(p.angle*Math.PI/180)>p.depth-2*p.wall-p.phoneGap-2)throw new Error('The phone back leans beyond the board. Increase depth, reduce tilt, or lower the phone back.');
}
const box=(size,center)=>cuboid({size,center});
function footprint(w,d,r,c=[0,0]) {
  return r>0.01 ? roundedRectangle({size:[w,d],roundRadius:Math.min(r,w/2-0.01,d/2-0.01),segments:48,center:c}) : rectangle({size:[w,d],center:c});
}
const slab=(w,d,r,z,h)=>translate([0,0,z],extrudeLinear({height:h},footprint(w,d,r,[0,d/2])));

export function hookLayout(p,w=p.width,test=false) {
  const rows=p.hookType==='double'?2:1;
  const auto=Math.max(1,Math.min(Math.floor(8/rows),Math.floor((w-14)/p.pitch)+1));
  const count=test?2:(p.hookCount===0?auto:p.hookCount/rows);
  if ((count-1)*p.pitch+p.slot> w-4) throw new Error('Shelf is too narrow for this hook spacing. Increase width or reduce spacing.');
  return Array.from({length:count},(_,i)=>(i-(count-1)/2)*p.pitch);
}

function hooks(p,positions) {
  const parts=[], width=p.slot-p.clearance, gap=p.board+p.clearance, neck=3.2, tail=2.4;
  for (const x of positions) for(const z of p.hookType==='double'?[26,26-p.rowPitch]:[26]) {
    // Downward tails enter the slot, then drop below its lower edge.
    // y=0 is the backplate contact plane; the board occupies -board..0.
    parts.push(box([width,gap+tail+0.3,neck],[x,-(gap+tail)/2+0.15,z+neck/2]));
    if(p.hookType==='tapered') {
      const tip=Math.max(2.4,width-1.2),section=rectangle({size:[tip,tail],center:[0,0]});
      const taper=track(section.extrude(3,0,0,[width/tip,1]));
      parts.push(translate([x,-gap-tail/2,z-p.hookDrop],taper));
      const h=p.hookDrop+neck-3+.15;
      parts.push(box([width,tail,h],[x,-gap-tail/2,z+neck-h/2]));
    } else parts.push(box([width,tail,p.hookDrop+neck],[x,-gap-tail/2,z+(neck-p.hookDrop)/2]));
  }
  return parts;
}

function ellipse(w,d,cy=d/2){const pts=Array.from({length:96},(_,i)=>{const a=i*Math.PI/48;return[w/2*Math.cos(a),cy+d/2*Math.sin(a)];});return polygon({points:pts});}
function semi(w,d){const pts=[[-w/2,0],[w/2,0]];for(let i=1;i<=48;i++){const a=i*Math.PI/48;pts.push([w/2*Math.cos(a),d*Math.sin(a)]);}return polygon({points:pts});}
function yzPrism(points,width,x=-width/2){return translate([x,0,0],rotateZ(Math.PI/2,rotateX(Math.PI/2,extrudeLinear({height:width},polygon({points})))));}
function underSupports(p,w,d){
  if(!p.bottomSupports)return {parts:[],count:0};
  const n=p.supportCount,b=p.supportThickness,span=Math.max(0,Math.min(w*.5,w-2*p.wall-b-8));
  if(n>1&&span/(n-1)<b+.5)throw new Error('The underside brackets are too close together. Reduce their count or thickness, or increase shelf width.');
  const parts=[],reaches=[];const slope=p.style==='tilted'?Math.tan(p.angle*Math.PI/180):0;
  for(let i=0;i<n;i++){
    const x=n===1?0:(i/(n-1)-.5)*span;
    let front=d;
    const ratio=Math.min(.99,(Math.abs(x)+b/2)/(w/2));
    if(p.style==='semicircle')front=d*Math.sqrt(1-ratio*ratio);
    if(p.style==='cup')front=d/2+d/2*Math.sqrt(1-ratio*ratio);
    if(p.style==='rounded'){
      const r=Math.min(p.radius,w/2-.01,d/2-.01),outside=Math.abs(x)+b/2;
      if(r>0&&outside>w/2-r)front=d-r+Math.sqrt(Math.max(0,r*r-(outside-(w/2-r))**2));
    }
    const reach=Math.min(p.supportReach,front-p.wall);
    reaches.push(reach);
    parts.push(yzPrism([[0,-p.supportHeight],[reach,slope*reach+.25],[0,.25]],b,x-b/2));
    const rise=Math.max(34,p.floor),h=p.supportHeight+rise;
    parts.push(box([b,p.wall,h],[x,p.wall/2,(rise-p.supportHeight)/2]));
  }
  return {parts,count:n,reaches};
}

export function buildShelf(p,test=false) {
  if(!M) throw new Error("The geometry engine is still loading.");
  validate(p,test);
  pool=[];
  try {
  const w=test?p.pitch+16:p.width, d=test?18:p.depth, t=p.wall;
  const positions=hookLayout(p,w,test), r=test?0:(p.style==='rounded'?p.radius:0);
  const edge=test||['flat','semicircle','holder','phone','tilted'].includes(p.style)?0:p.height;
  const backHeight=Math.max(34,p.floor+edge);
  let solid,extras=[],holeCuts=[];
  if(!test&&p.style==='semicircle')solid=extrudeLinear({height:p.floor},semi(w,d));
  else if(!test&&p.style==='cup'){
    const outside=extrudeLinear({height:p.floor+edge},ellipse(w,d));
    const inside=translate([0,0,p.floor],extrudeLinear({height:edge+1},ellipse(w-2*t,d-2*t,d/2)));
    solid=subtract(outside,inside);
    extras.push(box([w,Math.max(t,5),p.floor],[0,Math.max(t,5)/2,p.floor/2]));
  } else if(!test&&p.style==='phone'){
    solid=slab(w,d,0,0,p.floor);
    const seat=d-t-p.phoneGap,lean=p.phoneHeight*Math.tan(p.angle*Math.PI/180);
    extras.push(yzPrism([[seat-t,p.floor-.2],[seat,p.floor-.2],[seat-lean,p.floor+p.phoneHeight],[seat-lean-t,p.floor+p.phoneHeight]],w-2*t));
    const lip=box([w,t,14.2],[0,d-t/2,p.floor+7-.1]);
    const cable=box([14,24,p.floor+30],[0,d-4,10]);
    solid=subtract(solid,cable);extras.push(subtract(lip,cable));
  } else if(!test&&p.style==='tilted'){
    const rise=d*Math.tan(p.angle*Math.PI/180);
    solid=yzPrism([[0,0],[d,rise],[d,rise+p.floor],[0,p.floor]],w);
    const lipHeight=Math.max(8,p.wall*3);
    extras.push(box([w,t,lipHeight+.2],[0,d-t/2,rise+p.floor+lipHeight/2-.1]));
  } else if(!test&&p.style==='openbin'){
    const outside=slab(w,d,0,0,p.floor+edge);
    const inside=box([w-2*t,d-t+1,edge+1],[0,(d+t+1)/2,p.floor+(edge+1)/2]);
    solid=subtract(outside,inside);
  } else if (edge>0) {
    const outer=slab(w,d,r,0,p.floor+edge);
    const innerR=Math.max(0,r-t);
    const inner=translate([0,0,p.floor],extrudeLinear({height:edge+1},footprint(w-2*t,d-2*t,innerR,[0,d/2])));
    solid=subtract(outer,inner);
  } else solid=slab(w,d,r,0,p.floor);
  // Leave a straight, full-width mounting plane even on the rounded style.
  const backBottom=p.hookType==='double'?Math.min(0,26-p.rowPitch-p.hookDrop-3):0;
  const parts=[solid,...extras,box([w,t,backHeight-backBottom],[0,t/2,(backHeight+backBottom)/2]),...hooks(p,positions)];
  if (!test && ['tray','rounded','openbin'].includes(p.style) && p.compartments>1) {
    const clear=(w-2*t-(p.compartments-1)*t)/p.compartments;
    for(let i=1;i<p.compartments;i++) {
      const x=-w/2+t+i*clear+(i-0.5)*t;
      const end=p.style==='openbin'?d:d-t;
      parts.push(box([t,end-t+.2,edge+0.2],[x,(end+t)/2,p.floor+edge/2-0.1]));
    }
  }
  if (!test && p.braces && ['flat','tray','rounded','openbin'].includes(p.style)) {
    // Small gussets inside the two back corners join the wall to the floor.
    const reach=Math.min(d-t-1,34), h=Math.min(25,backHeight-1);
    const tri=polygon({points:[[t-0.2,p.floor-0.2],[reach,p.floor-0.2],[t-0.2,h]]});
    const rib=rotateZ(Math.PI/2,rotateX(Math.PI/2,extrudeLinear({height:t},tri)));
    for(const x of [-w/2+t,w/2-2*t]) parts.push(translate([x,0,0],rib));
  }
  const supports=test?{parts:[],count:0}:underSupports(p,w,d);parts.push(...supports.parts);
  if(!test&&p.style==='holder'){
    const clear=w-2*t,spacing=clear/p.holeCount;
    for(let i=0;i<p.holeCount;i++){
      const x=-clear/2+(i+.5)*spacing;
      const circle=track(CS.circle(p.holeDiameter/2,64));
      holeCuts.push(translate([x,d/2,-p.supportHeight-2],extrudeLinear({height:p.supportHeight+p.floor+5},circle)));
    }
  }
  let combined=union(parts);
  if(holeCuts.length)combined=track(combined.subtract(union(holeCuts)));
  const original=track(combined.asOriginal());
  const cleaned=track(original.simplify(0.001));
  const pieces=cleaned.decompose();pieces.forEach(track);
  if(pieces.length!==1)throw new Error('These settings produce separate pieces. Adjust the dimensions so every part connects to the shelf.');
  const mesh=cleaned.getMesh();
  const vertices=[],triangles=[];
  for(let i=0;i<mesh.vertProperties.length;i+=mesh.numProp) vertices.push(Array.from(mesh.vertProperties.slice(i,i+3)));
  for(let i=0;i<mesh.triVerts.length;i+=3) triangles.push(Array.from(mesh.triVerts.slice(i,i+3)));
  const bounds=[[Infinity,Infinity,Infinity],[-Infinity,-Infinity,-Infinity]];
  vertices.forEach(v=>v.forEach((n,j)=>{bounds[0][j]=Math.min(bounds[0][j],n);bounds[1][j]=Math.max(bounds[1][j],n);}));
  const dims=bounds[1].map((n,i)=>n-bounds[0][i]);
  const edges=new Map(); let volume=0;
  for(const ids of triangles) {
    for(let i=0;i<3;i++){const a=ids[i],b=ids[(i+1)%3],key=a<b?`${a},${b}`:`${b},${a}`;edges.set(key,(edges.get(key)||0)+1);}
    const [a,b,c]=ids.map(i=>vertices[i]);
    volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6;
  }
  const watertight=[...edges.values()].every(n=>n===2);
  if(!watertight || volume<=0) throw new Error('This combination could not produce a closed printable mesh. Adjust the corner radius or thickness.');
  const rows=p.hookType==='double'?2:1;
  return {vertices,triangles,bounds,dims,volume,watertight,hooks:positions.length*rows,rows,positions,test,supports:supports.count,supportReaches:supports.reaches||[],style:p.style};
  } finally {for(const o of pool.reverse())o.delete();pool=[];}
}

export function fitBed(mesh,p) {
  const [x,y,z]=mesh.dims;
  return { fits:z<=p.bedZ && ((x<=p.bedX && y<=p.bedY)||(y<=p.bedX && x<=p.bedY)),
    rotate:!(x<=p.bedX&&y<=p.bedY)&&y<=p.bedX&&x<=p.bedY, brimFits:z<=p.bedZ&&((x+10<=p.bedX&&y+10<=p.bedY)||(y+10<=p.bedX&&x+10<=p.bedY)) };
}
function exportVertices(m){return m.vertices.map(v=>v.map((n,j)=>n-m.bounds[0][j]));}
export function stl(m) {
  const vs=exportVertices(m), buffer=new ArrayBuffer(84+50*m.triangles.length), data=new DataView(buffer);
  new Uint8Array(buffer).set(strToU8('SKADIS Shelf Studio | millimeters | model only'));
  data.setUint32(80,m.triangles.length,true);
  m.triangles.forEach((ids,i)=>{
    let off=84+i*50;const [a,b,c]=ids.map(id=>vs[id]);
    const u=b.map((n,j)=>n-a[j]),v=c.map((n,j)=>n-a[j]);
    const normal=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];
    const len=Math.hypot(...normal)||1;
    [...normal.map(n=>n/len),...a,...b,...c].forEach(n=>{data.setFloat32(off,n,true);off+=4;});
  });return new Uint8Array(buffer);
}
export function threeMF(m,p) {
  const vs=exportVertices(m);
  const xml=`<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02"><metadata name="Title">SKADIS ${m.test?'hook fit test':'custom shelf'}</metadata><metadata name="Designer">SKADIS Shelf Studio</metadata><metadata name="Description">Model only. Choose your printer and slice in your preferred slicer. ${p.width} x ${p.depth} mm.</metadata><resources><object id="1" type="model"><mesh><vertices>${vs.map(v=>`<vertex x="${v[0]}" y="${v[1]}" z="${v[2]}"/>`).join('')}</vertices><triangles>${m.triangles.map(t=>`<triangle v1="${t[0]}" v2="${t[1]}" v3="${t[2]}"/>`).join('')}</triangles></mesh></object></resources><build><item objectid="1"/></build></model>`;
  return zipSync({
    '[Content_Types].xml':strToU8('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'),
    '_rels/.rels':strToU8('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'),
    '3D/3dmodel.model':strToU8(xml)
  },{level:6});
}
